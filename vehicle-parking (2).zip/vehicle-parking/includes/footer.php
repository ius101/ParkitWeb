<footer>
	<div class="col-sm-12">
		<p class="back-link">&copy; <?php echo date("Y"); ?>  </p>
	</div>
</footer>